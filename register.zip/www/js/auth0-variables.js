var AUTH0_CLIENT_ID='AlsxGZ5UMKMeK1LjzS8RSmA5RshEZ7dl'; 
var AUTH0_DOMAIN='marlonruo.auth0.com'; 
var AUTH0_CALLBACK_URL=location.href;